import javax.swing.*;  // Impor kelas-kelas untuk GUI Swing
import java.awt.*;  // Impor kelas-kelas untuk layout dan grafik
import java.awt.event.*;  // Impor kelas-kelas untuk penanganan event
import java.io.*;  // Impor kelas-kelas untuk I/O (Input/Output)
import java.net.Socket;  // Impor kelas Socket untuk jaringan
import java.util.Arrays;  // Impor kelas Arrays untuk manipulasi array
import javax.swing.filechooser.FileNameExtensionFilter;  // Impor kelas untuk filter file di file chooser
import java.util.concurrent.ExecutionException;  // Impor kelas untuk menangani eksepsi dalam SwingWorker

public class Client {
    // Deklarasi komponen-komponen GUI
    private JFrame frame = new JFrame("Chat Client");  // Frame utama aplikasi
    private JTextField textField = new JTextField(40);  // Field teks untuk input pesan
    private JTextArea messageArea = new JTextArea(16, 50);  // Area teks untuk menampilkan pesan
    private JList<String> userList = new JList<>();  // Daftar pengguna
    private DefaultListModel<String> listModel = new DefaultListModel<>();  // Model untuk daftar pengguna
    private JButton sendFileButton = new JButton("Send File");  // Tombol untuk mengirim file
    private JFileChooser fileChooser = new JFileChooser();  // File chooser untuk memilih file

    // Deklarasi variabel untuk jaringan
    private BufferedReader in;  // Untuk membaca input dari server
    private PrintWriter out;  // Untuk menulis output ke server
    private Socket socket;  // Soket untuk koneksi jaringan

    // Konstruktor klien dengan alamat server
    public Client(String serverAddress) throws IOException {
        // Setup GUI
        textField.setEditable(false);  // Membuat field teks tidak dapat diedit sampai koneksi terjalin
        messageArea.setEditable(false);  // Membuat area teks tidak dapat diedit
        userList.setModel(listModel);  // Mengatur model untuk daftar pengguna

        // Layout
        frame.getContentPane().add(new JScrollPane(messageArea), BorderLayout.CENTER);  // Menambahkan area teks ke frame
        frame.getContentPane().add(new JScrollPane(userList), BorderLayout.EAST);  // Menambahkan daftar pengguna ke frame

        // Panel di bagian bawah frame
        JPanel southPanel = new JPanel(new FlowLayout());  // Membuat panel dengan flow layout
        southPanel.add(textField);  // Menambahkan field teks ke panel
        southPanel.add(sendFileButton);  // Menambahkan tombol kirim file ke panel
        frame.getContentPane().add(southPanel, BorderLayout.SOUTH);  // Menambahkan panel ke frame

        frame.pack();  // Mengatur ukuran frame berdasarkan komponen di dalamnya

        // Setup file chooser
        setupFileChooser();

        // Listener untuk tombol kirim file
        sendFileButton.addActionListener(e -> {
            int result = fileChooser.showOpenDialog(frame);  // Menampilkan dialog file chooser
            if (result == JFileChooser.APPROVE_OPTION) {  // Jika file dipilih
                File fileToSend = fileChooser.getSelectedFile();  // Mengambil file yang dipilih
                sendFile(fileToSend);  // Mengirim file
            }
        });

        // Listener untuk field teks
        textField.addActionListener(e -> {
            out.println("MESSAGE " + textField.getText());  // Mengirim pesan ke server
            textField.setText("");  // Mengosongkan field teks setelah mengirim
        });

        // Setup koneksi jaringan
        socket = new Socket(serverAddress, 1234);  // Membuka soket ke server
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));  // Membuka reader untuk input dari server
        out = new PrintWriter(socket.getOutputStream(), true);  // Membuka writer untuk output ke server

        // Listener thread
        Thread listenerThread = new Thread(() -> {
            try {
                while (true) {
                    String line = in.readLine();  // Membaca baris dari server
                    // Proses berdasarkan prefix dari pesan
                    if (line.startsWith("SUBMITNAME")) {
                        // Jika server meminta nama
                        String name = JOptionPane.showInputDialog(
                            frame,
                            "Choose a screen name:",
                            "Screen name selection",
                            JOptionPane.PLAIN_MESSAGE);
                        out.println(name);  // Mengirim nama ke server
                    } else if (line.startsWith("SUBMITNIM")) {
                        // Jika server meminta NIM
                        String nim = JOptionPane.showInputDialog(
                            frame,
                            "Enter your NIM:",
                            "NIM Entry",
                            JOptionPane.PLAIN_MESSAGE);
                        out.println(nim);  // Mengirim NIM ke server
                    } else if (line.startsWith("NAMEACCEPTED")) {
                        textField.setEditable(true);  // Mengaktifkan field teks setelah nama diterima
                    } else if (line.startsWith("MESSAGE")) {
                        messageArea.append(line.substring(8) + "\n");  // Menambahkan pesan ke area teks
                    } else if (line.startsWith("USERLIST")) {
                        // Jika server mengirim daftar pengguna
                        String[] userArray = line.substring(9).split(",");  // Memecah string menjadi array
                        listModel.removeAllElements();  // Menghapus semua elemen dari model
                        Arrays.asList(userArray).forEach(listModel::addElement);  // Menambahkan pengguna ke model
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(frame, "Connection error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        listenerThread.start();  // Memulai thread
    }

    // Metode untuk mengatur file chooser
   
     }


   
    private void setupFileChooser() {
        FileNameExtensionFilter filter = new FileNameExtensionFilter(
            "JPG, JPEG, PNG, PDF Files", "jpg", "jpeg", "png", "pdf");
        fileChooser.setFileFilter(filter);  // Mengatur filter file
    }
   // Metode untuk mengirim file ke server
    private void sendFile(File file) {
        new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() throws Exception {
			     // ... [kode mengirim file]
                try {
                    long fileSize = file.length();
                    out.println("FILE " + file.getName() + " " + fileSize);
                    FileInputStream fis = new FileInputStream(file);
                    BufferedInputStream bis = new BufferedInputStream(fis);

                    byte[] buffer = new byte[40000096];
                    int bytesRead;
                    while ((bytesRead = bis.read(buffer, 0, buffer.length)) != -1) {
                        socket.getOutputStream().write(buffer, 0, bytesRead);
                    }
                    socket.getOutputStream().flush();
                    bis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(frame, "Error sending file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
                return null;
            }

            @Override
            protected void done() {
			  // ... [kode setelah file terkirim]
                try {
                    get();
                    JOptionPane.showMessageDialog(frame, "File sent successfully: " + file.getName(), "File Sent", JOptionPane.INFORMATION_MESSAGE);
                } catch (InterruptedException | ExecutionException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(frame, "Error in sending file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }.execute();
    }
    // Metode utama untuk menjalankan aplikasi
    public static void main(String[] args) throws Exception {
        Client client = new Client("localhost");  // Membuat instansi klien dengan alamat server
        client.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  // Mengatur operasi tutup frame
        client.frame.setVisible(true);  // Menampilkan frame
    }
}
