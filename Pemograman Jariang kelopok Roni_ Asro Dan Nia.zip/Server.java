import javax.swing.*;  // Impor kelas-kelas untuk GUI Swing
import java.awt.*;  // Impor kelas-kelas untuk layout dan grafik
import java.io.*;  // Impor kelas-kelas untuk I/O (Input/Output)
import java.net.ServerSocket;  // Impor kelas ServerSocket untuk server jaringan
import java.net.Socket;  // Impor kelas Socket untuk koneksi jaringan
import java.text.SimpleDateFormat;  // Impor kelas untuk format tanggal
import java.util.Collections;  // Impor kelas Collections untuk kumpulan thread-safe
import java.util.Date;  // Impor kelas Date
import java.util.HashSet;  // Impor kelas HashSet
import java.util.Set;  // Impor kelas Set

public class Server {
    private int port;  // Port untuk server socket
    private Set<ClientHandler> clientHandlers = Collections.synchronizedSet(new HashSet<>());  // Kumpulan handler klien yang thread-safe
    private JFrame logFrame;  // Frame GUI untuk log
    private JTextArea logTextArea;  // Area teks untuk menampilkan log

    // Konstruktor server dengan port tertentu
    public Server(int port) {
        this.port = port;
        initializeLogViewer();  // Inisialisasi GUI untuk log
    }

    // Inisialisasi GUI log viewer
    private void initializeLogViewer() {
        logFrame = new JFrame("Server Log Viewer");
        logTextArea = new JTextArea(20, 50);
        logTextArea.setEditable(false);  // Membuat log area teks tidak dapat diedit

        logFrame.add(new JScrollPane(logTextArea), BorderLayout.CENTER);  // Menambahkan log area teks ke frame
        logFrame.pack();  // Mengatur ukuran frame berdasarkan komponen di dalamnya
        logFrame.setVisible(true);  // Menampilkan frame
    }

    // Metode untuk menambahkan pesan ke log viewer
    private synchronized void updateLogViewer(String message) {
        SwingUtilities.invokeLater(() -> logTextArea.append(message + "\n"));  // Menambahkan pesan ke area teks log
    }

    // Metode untuk memulai server
    public void start() {
        try (ServerSocket serverSocket = new ServerSocket(port)) {  // Menciptakan server socket
            updateLogViewer("Chat Server is running on port " + port);
            while (true) {
                Socket clientSocket = serverSocket.accept();  // Menunggu dan menerima koneksi klien
                ClientHandler handler = new ClientHandler(clientSocket);  // Membuat handler baru untuk klien
                clientHandlers.add(handler);  // Menambahkan handler ke kumpulan
                handler.start();  // Memulai thread handler
            }
        } catch (IOException e) {
            updateLogViewer("Server exception: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Kelas inner untuk menangani klien
    private class ClientHandler extends Thread {
        private Socket socket;  // Soket untuk koneksi klien
        private BufferedReader in;  // Untuk membaca input dari klien
        private PrintWriter out;  // Untuk menulis output ke klien
        private String name;  // Nama klien
        private String nim;  // NIM klien

        // Konstruktor handler klien
        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        // Metode yang dijalankan oleh thread
        public void run() {
            try {
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));  // Membuka reader untuk input dari klien
                out = new PrintWriter(socket.getOutputStream(), true);  // Membuka writer untuk output ke klien

                requestUserInfo();  // Meminta informasi pengguna

                String line;
                while ((line = in.readLine()) != null) {  // Membaca pesan dari klien
                    if (line.startsWith("FILE")) {  // Jika pesan adalah permintaan file
                        receiveFile(line);  // Menerima file
                    } else if (line.startsWith("MESSAGE")) {  // Jika pesan adalah pesan teks
                        broadcastMessage(name + ": " + line.substring(8));  // Meneruskan pesan ke semua klien
                    }
                }
            } catch (IOException e) {
                updateLogViewer("Error handling client " + name + ": " + e.getMessage());
            } finally {
                cleanUp();  // Membersihkan sumber daya
            }
        }

        // Meminta nama dan NIM dari klien
        private void requestUserInfo() throws IOException {
            while (name == null || nim == null) {
                out.println(name == null ? "SUBMITNAME" : "SUBMITNIM");  // Meminta nama atau NIM
                if (name == null) {
                    name = in.readLine();  // Membaca nama
                } else {
                    nim = in.readLine();  // Membaca NIM
                }
            }
            out.println("NAMEACCEPTED " + name + " " + nim);  // Mengonfirmasi nama dan NIM
            broadcastMessage(name + " (" + nim + ") has joined");  // Mengumumkan kedatangan klien
            updateClientList();  // Memperbarui daftar klien
        }

        // Metode untuk menerima file dari klien
      private void receiveFile(String headerLine) throws IOException {
            String[] headerParts = headerLine.split(" ");
            String originalFileName = headerParts[1];
            long fileSize = Long.parseLong(headerParts[2]);
            byte[] fileBytes = new byte[(int) fileSize];

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
            String timestamp = dateFormat.format(new Date());
            String modifiedFileName = timestamp + "_" + name + "_" + originalFileName;

            InputStream is = socket.getInputStream();
            BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream("server_files/" + modifiedFileName));

            int bytesRead, current = 0;
            while (current < fileSize) {
                bytesRead = is.read(fileBytes, current, fileBytes.length - current);
                if (bytesRead >= 0) current += bytesRead;
            }
            bos.write(fileBytes, 0, current);
            bos.flush();
            bos.close();

            broadcastMessage(name + " has sent a file: " + modifiedFileName);
        }
 

        // Meneruskan pesan ke semua klien
        private void broadcastMessage(String message) {
            updateLogViewer(message);  // Menambahkan pesan ke log server
            for (ClientHandler client : clientHandlers) {  // Mengirim pesan ke semua klien
                client.out.println("MESSAGE " + message);
            }
        }

        // Memperbarui daftar klien
        private void updateClientList() {
            StringBuilder userList = new StringBuilder("USERLIST ");
            for (ClientHandler client : clientHandlers) {  // Membuat daftar nama klien
                userList.append(client.name).append(",");
            }
            String userListStr = userList.toString();
            for (ClientHandler client : clientHandlers) {  // Mengirim daftar ke semua klien
                client.out.println(userListStr);
                updateLogViewer("Updated user list sent to " + client.name);
            }
        }

        // Membersihkan sumber daya ketika klien keluar
        private void cleanUp() {
            if (name != null) {
                clientHandlers.remove(this);  // Menghapus handler dari kumpulan
                broadcastMessage(name + " has left");  // Mengumumkan kepergian klien
                updateClientList();  // Memperbarui daftar klien
            }
            try {
                socket.close();  // Menutup soket
            } catch (IOException e) {
                updateLogViewer("Error closing socket for " + name + ": " + e.getMessage());
            }
        }
    }

    // Metode utama untuk menjalankan server
    public static void main(String[] args) throws Exception {
        int port = args.length > 0 ? Integer.parseInt(args[0]) : 1234;  // Menentukan port
        Server server = new Server(port);  // Membuat instansi server
        server.start();  // Memulai server
    }
}
